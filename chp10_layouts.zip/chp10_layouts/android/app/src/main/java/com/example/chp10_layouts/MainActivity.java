package com.example.chp10_layouts;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
